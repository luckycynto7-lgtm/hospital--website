let form = document.getElementById("patientForm");
let table = document.querySelector("#patientTable tbody");

// Load saved data
window.onload = function () {
    let patients = JSON.parse(localStorage.getItem("patients")) || [];
    patients.forEach(addRow);
};

form.addEventListener("submit", function (e) {
    e.preventDefault();

    let patient = {
        fname: fname.value,
        lname: lname.value,
        id: id.value,
        gender: gender.value,
        diagnosis: diagnosis.value,
        drug: drug.value
    };

    addRow(patient);

    let patients = JSON.parse(localStorage.getItem("patients")) || [];
    patients.push(patient);
    localStorage.setItem("patients", JSON.stringify(patients));

    form.reset();
});

function addRow(p) {
    let row = `<tr>
        <td>${p.fname}</td>
        <td>${p.lname}</td>
        <td>${p.id}</td>
        <td>${p.gender}</td>
        <td>${p.diagnosis}</td>
        <td>${p.drug}</td>
    </tr>`;

    table.innerHTML += row;
}// Select form and table
let form = document.getElementById("memberForm");
let table = document.querySelector("#memberTable tbody");

// Load saved members
window.onload = function () {
    let members = JSON.parse(localStorage.getItem("members")) || [];
    members.forEach(addRow);
};

// On form submit
form.addEventListener("submit", function(e) {
    e.preventDefault();

    // Validate passwords match
    let pwd = document.getElementById("password").value;
    let confirmPwd = document.getElementById("confirmPassword").value;

    if(pwd !== confirmPwd) {
        alert("Passwords do not match!");
        return;
    }

    // Get form values
    let member = {
        fname: document.getElementById("fname").value,
        sname: document.getElementById("sname").value,
        phone: document.getElementById("phone").value,
        gender: document.querySelector('input[name="gender"]:checked').value,
        age: document.getElementById("age").value
    };

    // Add to table
    addRow(member);

    // Save to "database" (localStorage)
    let members = JSON.parse(localStorage.getItem("members")) || [];
    members.push(member);
    localStorage.setItem("members", JSON.stringify(members));

    // Reset form
    form.reset();
});

// Function to add a member to table
function addRow(m) {
    let row = `<tr>
        <td>${m.fname}</td>
        <td>${m.sname}</td>
        <td>${m.phone}</td>
        <td>${m.gender}</td>
        <td>${m.age}</td>
    </tr>`;
    table.innerHTML += row;
}